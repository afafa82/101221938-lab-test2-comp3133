import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Spacexes } from "../model/spacexes";

export class SpacexapiService{
    url = "https://api.spacexdata.com/v3/launches"
    constructor(private http: HttpClient){
        this.getSpacexes()
    }


    getSpacexes(){
        return this.http.get(this.url).subscribe((response)=>{
            alert(JSON.stringify(response))
        })
    }
}
