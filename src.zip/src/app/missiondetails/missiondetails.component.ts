import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'app-missiondetails',
  templateUrl: './missiondetails.component.html',
  styleUrls: ['./missiondetails.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MissiondetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
